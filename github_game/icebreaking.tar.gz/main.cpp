#include "Menu.hpp"
#include "Random.hpp"

int main() {
	Menu menu;
	menu.run();
	return 0;
}